"use client"

import Image from "next/image"
import { PlusCircle } from "lucide-react"
import { AnimatedDiv } from "@/components/animated-div"

export default function HomePage() {
  return (
    // Global wrapper to prevent horizontal scrollbar and ensure full width background
    <div className="w-full overflow-x-hidden">
      {/* Hero Section (Page 01) - No horizontal padding here */}
      <div className="relative min-h-screen w-full overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image src="/home page.png" alt="Elegant hotel corridor" fill className="object-cover" priority />
          {/* Dark overlay for better text readability */}
          <div className="absolute inset-0 bg-black/40" />
        </div>

        {/* Content */}
        <div className="relative z-10 flex min-h-screen flex-col">
          {/* Header */}
          <header className="p-8">
            <div className="max-w-screen-2xl mx-auto px-8 flex justify-between w-full">
              {/* Top Left - Right Arm */}
              <div className="text-white">
                <span
                  style={{
                    fontSize: "12px",
                    fontFamily: '"Proxima Nova Regular", sans-serif',
                    fontWeight: "normal",
                    color: "#f4f5f3",
                  }}
                >
                  RIGHT ARM
                </span>
              </div>

              {/* Top Right - Logo */}
              <div className="text-white">
                <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
              </div>
            </div>
          </header>

          {/* Main Content - Center */}
          <main className="flex flex-1 items-center justify-center px-8">
            <AnimatedDiv direction="down" delay={200} className="text-center text-white">
              <AnimatedDiv direction="down" delay={400}>
                <h1
                  className="mb-4 tracking-wide"
                  style={{ fontSize: "81.3px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
                >
                  Tourism business
                </h1>
              </AnimatedDiv>
              <AnimatedDiv
                direction="up"
                delay={600}
                style={{
                  fontSize: "17.1px",
                  fontFamily: '"Proxima Nova Regular", sans-serif',
                  fontWeight: "normal",
                  letterSpacing: "0.1em", // Add letter spacing
                }}
              >
                R I G H T&nbsp;&nbsp;A R M
              </AnimatedDiv>
            </AnimatedDiv>
          </main>

          {/* Footer */}
          <footer className="p-8">
            <div className="max-w-screen-2xl mx-auto px-8">
              <div className="flex items-center justify-between w-full text-gray-400">
                <span
                  style={{ fontSize: "15px", fontFamily: '"Proxima Nova Regular", sans-serif', fontWeight: "normal" }}
                >
                  <a href="https://rightarm.site" target="_blank" rel="noopener noreferrer" className="hover:underline">
                    rightarm.site
                  </a>
                </span>
                <span
                  style={{ fontSize: "15px", fontFamily: '"Proxima Nova Regular", sans-serif', fontWeight: "normal" }}
                >
                  <a href="tel:+966566705302" target="_blank" rel="noopener noreferrer" className="hover:underline">
                    966566705302
                  </a>
                </span>
                <span
                  style={{ fontSize: "15px", fontFamily: '"Proxima Nova Regular", sans-serif', fontWeight: "normal" }}
                >
                  <a
                    href="mailto:info.arm.me@gmail.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:underline"
                  >
                    info.arm.me@gmail.com
                  </a>
                </span>
                <span
                  style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
                  className="text-gray-400"
                >
                  Page 01
                </span>
              </div>
            </div>
          </footer>
        </div>
      </div>

      {/* About Us Section (Page 02) */}
      <div className="w-full" style={{ backgroundColor: "#161616" }}>
        <div className="max-w-screen-2xl mx-auto px-8">
          {/* Section Header */}
          <div className="flex items-center justify-between p-8">
            <span
              style={{
                fontSize: "12px",
                fontFamily: '"Proxima Nova Regular", sans-serif',
                fontWeight: "normal",
                color: "#f4f5f3",
              }}
              className="text-white"
            >
              RIGHT ARM
            </span>
            <div className="text-white">
              <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
            </div>
          </div>

          {/* Main Content */}
          <div className="flex items-start gap-16 px-8 pb-4">
            {/* Left - Image */}
            <div className="flex-shrink-0">
              <AnimatedDiv direction="left" delay={200}>
                <Image
                  src="/second.png"
                  alt="Modern hotel room"
                  width={660}
                  height={450}
                  className="object-cover"
                  priority // Added priority for faster loading
                />
              </AnimatedDiv>
            </div>

            {/* Right - Content */}
            <div className="flex-1">
              <div className="pl-8">
                {" "}
                {/* Added pl-8 to align all text content consistently */}
                <AnimatedDiv direction="right" delay={200}>
                  <h2
                    style={{ fontSize: "48px", fontFamily: '"The Seasons", serif', color: "#ada070" }}
                    className="mb-4"
                  >
                    About Us
                  </h2>
                </AnimatedDiv>
                <AnimatedDiv direction="right" delay={300}>
                  {/* Decorative line */}
                  <div className="flex items-center gap-4 mb-2">
                    <div className="w-16 h-0.5" style={{ backgroundColor: "#ada070" }}></div>
                    <p style={{ fontSize: "17.1px", color: "#ada070" }} className="text-left">
                      Introduction to our work in the field of tourism
                    </p>
                  </div>
                </AnimatedDiv>
                <AnimatedDiv direction="right" delay={400}>
                  <p style={{ fontSize: "17.1px", color: "#ada070" }} className="text-left mb-4">
                    مقدمة عن عملنا في مجال السياحة
                  </p>
                </AnimatedDiv>
                <AnimatedDiv direction="right" delay={500} className="space-y-6">
                  <p style={{ fontSize: "13px", color: "white" }} className="leading-relaxed text-left">
                    شركتنا في المدينة المنورة متخصصة في تسويق الفنادق والقطاع السياحي، نقدم خدمات التصوير والتصميم
                    وإدارة الحسابات والحملات الإعلانية، ونهدف لزيادة الحجوزات والمبيعات من خلال استراتيجيات تسويقية
                    مبتكرة.
                  </p>
                  <p style={{ fontSize: "13px", color: "white" }} className="leading-relaxed text-left">
                    Our company in Madinah specializes in marketing hotels and the tourism sector. We offer photography,
                    design, account management, and advertising campaigns, aiming to increase bookings and sales through
                    innovative marketing strategies.
                  </p>
                </AnimatedDiv>
              </div>
            </div>
          </div>
          <div className="flex justify-end p-8">
            <span
              style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
              className="text-gray-400"
            >
              Page 02
            </span>
          </div>
        </div>
      </div>

      {/* New Section - Page 03 */}
      <div className="w-full min-h-screen" style={{ backgroundColor: "#161616" }}>
        <div className="max-w-screen-2xl mx-auto px-8 flex flex-col h-full">
          {/* Section Header */}
          <header className="flex items-center justify-between p-8">
            {/* Top Left - Right Arm */}
            <div className="text-white">
              <span
                style={{
                  fontSize: "12px",
                  fontFamily: '"Proxima Nova Regular", sans-serif',
                  fontWeight: "normal",
                  color: "#f4f5f3",
                }}
              >
                RIGHT ARM
              </span>
            </div>

            {/* Top Right - Logo */}
            <div className="text-white">
              <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
            </div>
          </header>

          {/* Main Content - Image Left, Text/List Right */}
          <div className="flex flex-1 items-center justify-center px-8 pb-8 gap-12">
            {" "}
            {/* Changed flex-col to flex, items-center to items-start, and added gap-12 */}
            {/* Left - Image */}
            <div className="flex-shrink-0 flex flex-col justify-center h-full">
              {" "}
              {/* Added flex-col justify-center h-full for vertical centering */}
              <AnimatedDiv direction="left" delay={200}>
                <Image
                  src="/third.png"
                  alt="Modern hotel lobby with tree and fountain"
                  width={600}
                  height={360}
                  className="object-cover rounded-lg shadow-lg"
                  priority
                />
              </AnimatedDiv>
            </div>
            {/* Right - Services List and Title */}
            <div className="flex-1 pt-0">
              {/* Heading and Line */}
              <AnimatedDiv direction="right" delay={300}>
                <div className="flex flex-col items-center mb-4">
                  {" "}
                  {/* Changed items-start to items-center for horizontal centering */}
                  <h2
                    style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }}
                    className="mb-0"
                  >
                    Our services
                  </h2>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-0.5" style={{ backgroundColor: "#ada070" }}></div>
                    <p
                      style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }}
                      className="text-left"
                    >
                      خدماتنا
                    </p>
                  </div>
                </div>
              </AnimatedDiv>
              <div className="space-y-6 w-full">
                {" "}
                {/* Removed max-w-lg to allow full width */}
                {/* Service Item 1 (Left-aligned) */}
                <AnimatedDiv direction="left" delay={400}>
                  <div className="flex items-start justify-start gap-4">
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                    <div className="flex flex-col items-start text-left">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Social Media Management
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        إدارة وسائل التواصل الاجتماعي
                      </p>
                    </div>
                  </div>
                </AnimatedDiv>
                {/* Service Item 2 (Right-aligned) */}
                <AnimatedDiv direction="right" delay={500}>
                  <div className="flex items-start justify-end gap-4">
                    <div className="flex flex-col items-end text-right">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Paid Advertising (PPC)
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        إدارة الإعلانات المدفوعة(PPC)
                      </p>
                    </div>
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                  </div>
                </AnimatedDiv>
                {/* Service Item 3 (Left-aligned) */}
                <AnimatedDiv direction="left" delay={600}>
                  <div className="flex items-start justify-start gap-4">
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                    <div className="flex flex-col items-start text-left">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Search Engine Optimization (SEO)
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        تحسين محركات البحث (SEO)
                      </p>
                    </div>
                  </div>
                </AnimatedDiv>
                {/* Service Item 4 (Right-aligned) */}
                <AnimatedDiv direction="right" delay={700}>
                  <div className="flex items-start justify-end gap-4">
                    <div className="flex flex-col items-end text-right">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Content Marketing
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        إنشاء المحتوى الإبداعي
                      </p>
                    </div>
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                  </div>
                </AnimatedDiv>
                {/* Service Item 5 (Left-aligned) */}
                <AnimatedDiv direction="left" delay={800}>
                  <div className="flex items-start justify-start gap-4">
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                    <div className="flex flex-col items-start text-left">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Creative Design for Posts and Content
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        تصميم إبداعي للمنشورات والمحتوى
                      </p>
                    </div>
                  </div>
                </AnimatedDiv>
                {/* Service Item 6 (Right-aligned) */}
                <AnimatedDiv direction="right" delay={900}>
                  <div className="flex items-start justify-end gap-4">
                    <div className="flex flex-col items-end text-right">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Professional Photo & Video Production
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        إنتاج فيديوهات وصور احترافية
                      </p>
                    </div>
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                  </div>
                </AnimatedDiv>
                {/* Service Item 7 (Left-aligned) */}
                <AnimatedDiv direction="left" delay={1000}>
                  <div className="flex items-start justify-start gap-4">
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                    <div className="flex flex-col items-start text-left">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Visual Identity & Print Design
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        تصميم الهوية البصرية والمطبوعات
                      </p>
                    </div>
                  </div>
                </AnimatedDiv>
                {/* Service Item 8 (Right-aligned) */}
                <AnimatedDiv direction="right" delay={1100}>
                  <div className="flex items-start justify-end gap-4">
                    <div className="flex flex-col items-end text-right">
                      <p
                        style={{
                          fontSize: "17px",
                          color: "#ada070",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                          fontWeight: "bold",
                        }}
                      >
                        Sponsorship & Events
                      </p>
                      <p
                        style={{
                          fontSize: "15px",
                          color: "white",
                          fontFamily: '"Proxima Nova Regular", sans-serif',
                        }}
                      >
                        تنسيق الرعاية والفعاليات
                      </p>
                    </div>
                    <div className="w-3 h-3 rounded-full border border-[#ada070] flex items-center justify-center flex-shrink-0 mt-2">
                      <div className="w-1 h-1 rounded-full bg-white"></div>
                    </div>
                  </div>
                </AnimatedDiv>
              </div>
            </div>
          </div>

          {/* Page Counter */}
          <footer className="p-8 flex justify-end w-full">
            <span
              style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
              className="text-gray-400"
            >
              Page 03
            </span>
          </footer>
        </div>
      </div>

      {/* Our Business Section - Page 04 */}
      <div className="w-full" style={{ backgroundColor: "#161616" }}>
        <div className="max-w-screen-2xl mx-auto px-8">
          {/* Section Header - Adjusted for Page 04 */}
          <header className="flex items-center justify-between p-8">
            {/* RIGHT ARM on the left */}
            <div className="text-white">
              <span
                style={{
                  fontSize: "12px",
                  fontFamily: '"Proxima Nova Regular", sans-serif',
                  fontWeight: "normal",
                  color: "#f4f5f3",
                }}
              >
                RIGHT ARM
              </span>
            </div>

            {/* Center - Title */}
            <div className="flex flex-col items-center">
              <h2 style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }} className="mb-0">
                Our business
              </h2>
              <div className="flex items-center gap-4">
                {" "}
                {/* Changed gap-2 to gap-4 */}
                <p
                  style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }}
                  className="text-right"
                >
                  أعمالنا
                </p>
                <div className="w-16 h-0.5" style={{ backgroundColor: "#ada070" }}></div>
              </div>
            </div>

            {/* Logo on the right */}
            <div className="text-white pl-8">
              <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
            </div>
          </header>

          {/* Image Gallery */}
          <div className="flex justify-center gap-8 px-8 pb-8">
            {/* Rooms Image */}
            <AnimatedDiv direction="up" delay={200}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/Rooms.png" alt="Modern hotel room" fill className="object-cover" />
                </div>
                <div
                  className="flex items-center justify-center"
                  style={{ width: "402px", height: "67px", backgroundColor: "#192f50" }}
                >
                  <p className="text-white text-lg font-semibold">Rooms</p>
                </div>
              </div>
            </AnimatedDiv>

            {/* Housekeeping Image */}
            <AnimatedDiv direction="up" delay={400}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/Housekeeping.png" alt="Housekeeping service" fill className="object-cover" />
                </div>
                <div
                  className="flex items-center justify-center"
                  style={{ width: "402px", height: "67px", backgroundColor: "#192f50" }}
                >
                  <p className="text-white text-lg font-semibold">Housekeeping</p>
                </div>
              </div>
            </AnimatedDiv>

            {/* Chalets Image */}
            <AnimatedDiv direction="up" delay={600}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/Chalets.png" alt="Chalet with private pool" fill className="object-cover" />
                </div>
                <div
                  className="flex items-center justify-center"
                  style={{ width: "402px", height: "67px", backgroundColor: "#192f50" }}
                >
                  <p className="text-white text-lg font-semibold">Chalets</p>
                </div>
              </div>
            </AnimatedDiv>
          </div>

          {/* Page Counter */}
          <div className="flex justify-end p-8">
            <span
              style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
              className="text-gray-400"
            >
              Page 04
            </span>
          </div>
        </div>
      </div>

      {/* Our Facilities Section - Page 05 (Now "Our Business") */}
      <div className="w-full" style={{ backgroundColor: "#161616" }}>
        <div className="max-w-screen-2xl mx-auto px-8">
          {/* Section Header - Consistent with Page 04's new layout */}
          <header className="flex items-center justify-between p-8">
            {/* RIGHT ARM on the left */}
            <div className="text-white">
              <span
                style={{
                  fontSize: "12px",
                  fontFamily: '"Proxima Nova Regular", sans-serif',
                  fontWeight: "normal",
                  color: "#f4f5f3",
                }}
              >
                RIGHT ARM
              </span>
            </div>

            {/* Center - Title changed to "Our business" */}
            <div className="flex flex-col items-center">
              <h2 style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }} className="mb-0">
                Our business
              </h2>
              <div className="flex items-center gap-4">
                {" "}
                {/* Changed gap-2 to gap-4 */}
                <p
                  style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }}
                  className="text-right"
                >
                  أعمالنا
                </p>
                <div className="w-16 h-0.5" style={{ backgroundColor: "#ada070" }}></div>
              </div>
            </div>

            {/* Logo on the right */}
            <div className="text-white pl-8">
              <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
            </div>
          </header>

          {/* Image Gallery (Gym, Reception, Public facilities) */}
          <div className="flex justify-center gap-8 px-8 pb-8">
            {/* Gym Image */}
            <AnimatedDiv direction="up" delay={200}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/Gym.png" alt="Gym facilities" fill className="object-cover" />
                </div>
                <div
                  className="flex items-center justify-center"
                  style={{ width: "402px", height: "67px", backgroundColor: "#192f50" }}
                >
                  <p className="text-white text-lg font-semibold">Gym</p>
                </div>
              </div>
            </AnimatedDiv>

            {/* Reception Image */}
            <AnimatedDiv direction="up" delay={400}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/Reception.png" alt="Hotel reception area" fill className="object-cover" />
                </div>
                <div
                  className="flex items-center justify-center"
                  style={{ width: "402px", height: "67px", backgroundColor: "#192f50" }}
                >
                  <p className="text-white text-lg font-semibold">Reception</p>
                </div>
              </div>
            </AnimatedDiv>

            {/* Public facilities Image */}
            <AnimatedDiv direction="up" delay={600}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/Public-facilities.png" alt="General public facilities" fill className="object-cover" />
                </div>
                <div
                  className="flex items-center justify-center"
                  style={{ width: "402px", height: "67px", backgroundColor: "#192f50" }}
                >
                  <p className="text-white text-lg font-semibold">Public facilities</p>
                </div>
              </div>
            </AnimatedDiv>
          </div>

          {/* For More Button - Adjusted width and hover effect */}
          <div className="flex justify-center pb-8">
            <AnimatedDiv direction="up" delay={800}>
              <a
                href="https://drive.google.com/drive/folders/1lGoVfoPHiMhbV-spMTAor0bKTXDV_F3C?usp=share_link"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 w-fit px-8 py-4 rounded-full text-white font-semibold transition-transform duration-300 hover:scale-110"
                style={{ backgroundColor: "#192f50" }}
              >
                For more
                <PlusCircle className="w-5 h-5" />
              </a>
            </AnimatedDiv>
          </div>

          {/* Page Counter */}
          <div className="flex justify-end p-8">
            <span
              style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
              className="text-gray-400"
            >
              Page 05
            </span>
          </div>
        </div>
      </div>

      {/* Our Gallery Section - Page 06 (New Page) */}
      <div className="w-full" style={{ backgroundColor: "#161616" }}>
        <div className="max-w-screen-2xl mx-auto px-8">
          {/* Section Header - Consistent with Page 04 & 05 layout */}
          <header className="flex items-center justify-between p-8">
            {/* RIGHT ARM on the left */}
            <div className="text-white">
              <span
                style={{
                  fontSize: "12px",
                  fontFamily: '"Proxima Nova Regular", sans-serif',
                  fontWeight: "normal",
                  color: "#f4f5f3",
                }}
              >
                RIGHT ARM
              </span>
            </div>

            {/* Center - Title changed to "Our business" */}
            <div className="flex flex-col items-center">
              <AnimatedDiv direction="down" delay={200}>
                <h2 style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }} className="mb-0">
                  Our business
                </h2>
              </AnimatedDiv>
              <AnimatedDiv direction="down" delay={300}>
                <div className="flex items-center gap-4">
                  {" "}
                  {/* Changed gap-2 to gap-4 */}
                  <p
                    style={{ fontSize: "45px", fontFamily: '"The Seasons", serif', color: "#ada070" }}
                    className="text-right"
                  >
                    أعمالنا
                  </p>
                  <div className="w-16 h-0.5" style={{ backgroundColor: "#ada070" }}></div>
                </div>
              </AnimatedDiv>
            </div>

            {/* Logo on the right */}
            <div className="text-white pl-8">
              <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
            </div>
          </header>

          {/* Image Gallery (without text) */}
          <div className="flex justify-center gap-8 px-8 pb-8">
            {/* reception2 Image */}
            <AnimatedDiv direction="up" delay={400}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/reception2.png" alt="Hotel reception" fill className="object-cover" />
                </div>
              </div>
            </AnimatedDiv>

            {/* inside Image */}
            <AnimatedDiv direction="up" delay={600}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/inside.png" alt="Hotel interior" fill className="object-cover" />
                </div>
              </div>
            </AnimatedDiv>

            {/* livingRooms Image */}
            <AnimatedDiv direction="up" delay={800}>
              <div className="group flex flex-col items-center cursor-pointer transform transition-transform duration-300 hover:scale-105">
                <div className="relative w-[402px] h-[268px] overflow-hidden">
                  <Image src="/livingRooms.png" alt="Hotel living rooms" fill className="object-cover" />
                </div>
              </div>
            </AnimatedDiv>
          </div>

          {/* For More Button - Added to Page 06 */}
          <div className="flex justify-center pb-8">
            <AnimatedDiv direction="up" delay={1000}>
              <a
                href="https://drive.google.com/drive/folders/1ecrKgr2qVKuQNQU7Ip5Og1rJi7LCP5IN?usp=share_link"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 w-fit px-8 py-4 rounded-full text-white font-semibold transition-transform duration-300 hover:scale-110"
                style={{ backgroundColor: "#192f50" }} // Changed background to blue
              >
                For more
                <PlusCircle className="w-5 h-5" />
              </a>
            </AnimatedDiv>
          </div>

          {/* Page Counter */}
          <div className="flex justify-end p-8">
            <span
              style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
              className="text-gray-400"
            >
              Page 06
            </span>
          </div>
        </div>
      </div>

      {/* New Section - Page 07 */}
      <div className="w-full" style={{ backgroundColor: "#161616" }}>
        <div className="max-w-screen-2xl mx-auto px-8">
          {/* Section Header */}
          <header className="flex items-start justify-between p-8">
            {/* Top Left - Right Arm */}
            <div className="text-white">
              <span
                style={{
                  fontSize: "12px",
                  fontFamily: '"Proxima Nova Regular", sans-serif',
                  fontWeight: "normal",
                  color: "#f4f5f3",
                }}
              >
                RIGHT ARM
              </span>
            </div>

            {/* Top Right - Logo */}
            <div className="text-white">
              <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
            </div>
          </header>

          <div className="flex flex-col items-center justify-center min-h-[770px] py-8">
            {/* Video container - centered */}
            <AnimatedDiv direction="down" delay={400}>
              <video width="1000" height="600" controls muted autoPlay loop className="rounded-lg shadow-lg">
                <source src="/vid1.mp4" type="video/mp4" />
                {"Your browser does not support the video tag."}
              </video>
            </AnimatedDiv>

            {/* Text and Button Container - below video, text left, button right */}
            <div className="flex items-center justify-between w-[1000px] mt-8">
              <AnimatedDiv direction="right" delay={600}>
                <div className="flex flex-col items-start">
                  <div className="w-16 h-0.5 mb-2" style={{ backgroundColor: "#ada070" }}></div>
                  <h3 style={{ color: "#ada070", fontSize: "42px", fontFamily: '"The Seasons", serif' }}>
                    Example of video work
                  </h3>
                </div>
              </AnimatedDiv>
              <AnimatedDiv direction="left" delay={800}>
                <a
                  href="https://drive.google.com/drive/folders/17AWw3zHoA8fi2FmOvuvWh7DIA2VLFO3G?usp=share_link"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 w-fit px-8 py-4 rounded-full text-white font-semibold transition-transform duration-300 hover:scale-110"
                  style={{ backgroundColor: "#192f50" }} // Changed background to blue
                >
                  For more
                  <PlusCircle className="w-5 h-5" />
                </a>
              </AnimatedDiv>
            </div>
          </div>

          {/* Page Counter */}
          <div className="flex justify-end p-8">
            <span
              style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
              className="text-gray-400"
            >
              Page 07
            </span>
          </div>
        </div>
      </div>

      {/* New Section - Page 08 (Thank You Page) */}
      <div className="relative min-h-screen w-full overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image src="/Page8.png" alt="Hotel exterior at night with pool" fill className="object-cover" priority />
          {/* Dark overlay for better text readability */}
          <div className="absolute inset-0 bg-black/40" />
        </div>

        {/* Content */}
        <div className="relative z-10 flex min-h-screen flex-col">
          {/* Header */}
          <header className="p-8">
            <div className="max-w-screen-2xl mx-auto px-8 flex justify-between w-full">
              {/* Top Left - Right Arm */}
              <div className="text-white">
                <span
                  style={{
                    fontSize: "12px",
                    fontFamily: '"Proxima Nova Regular", sans-serif',
                    fontWeight: "normal",
                    color: "#f4f5f3",
                  }}
                >
                  RIGHT ARM
                </span>
              </div>

              {/* Top Right - Logo */}
              <div className="text-white">
                <Image src="/logo2.png" alt="Right Arm Logo" width={100} height={100} />
              </div>
            </div>
          </header>

          {/* Main Content - Center */}
          <main className="flex flex-1 flex-col items-center justify-center px-8">
            <AnimatedDiv direction="down" delay={200} className="text-center text-white">
              <h1
                className="mb-8 font-black tracking-wide"
                style={{ fontSize: "110px", fontFamily: '"The Seasons", serif', color: "white" }}
              >
                Thank You
              </h1>
            </AnimatedDiv>
            <AnimatedDiv direction="up" delay={400} className="pt-8">
              <a
                href="http://wa.me/966566705302"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:scale-110 transition-transform duration-300"
                aria-label="Chat on WhatsApp"
              >
                <Image
                  src="/whatsapp-icon.png"
                  alt="WhatsApp Icon"
                  width={64}
                  height={64}
                  style={{ filter: "invert(1)" }}
                />
              </a>
            </AnimatedDiv>
          </main>

          {/* Footer */}
          <footer className="p-8">
            <div className="max-w-screen-2xl mx-auto px-8">
              <div className="flex items-center justify-between w-full text-gray-400">
                <span
                  style={{ fontSize: "15px", fontFamily: '"Proxima Nova Regular", sans-serif', fontWeight: "normal" }}
                >
                  <a href="https://rightarm.site" target="_blank" rel="noopener noreferrer" className="hover:underline">
                    rightarm.site
                  </a>
                </span>
                <span
                  style={{ fontSize: "15px", fontFamily: '"Proxima Nova Regular", sans-serif', fontWeight: "normal" }}
                >
                  <a href="tel:+966566705302" target="_blank" rel="noopener noreferrer" className="hover:underline">
                    966566705302
                  </a>
                </span>
                <span
                  style={{ fontSize: "15px", fontFamily: '"Proxima Nova Regular", sans-serif', fontWeight: "normal" }}
                >
                  <a
                    href="mailto:info.arm.me@gmail.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:underline"
                  >
                    info.arm.me@gmail.com
                  </a>
                </span>
                <span
                  style={{ fontSize: "15px", fontFamily: '"The Seasons", serif', fontWeight: "normal" }}
                  className="text-gray-400"
                >
                  Page 08
                </span>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  )
}
